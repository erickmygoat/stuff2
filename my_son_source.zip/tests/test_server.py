import pytest
from fastapi.testclient import TestClient
from unittest.mock import MagicMock, patch
from my_son.server import app, daemon, executor

client = TestClient(app)

# Mock the secret token
SECRET_TOKEN = "1234"

@pytest.fixture
def auth_headers():
    return {"X-Auth-Token": SECRET_TOKEN}

def test_read_root():
    response = client.get("/")
    assert response.status_code == 200
    assert "My Son Interface" in response.text

def test_chat_endpoint_unauthorized():
    response = client.post("/api/chat", json={"message": "hello"})
    assert response.status_code == 401

def test_chat_endpoint(auth_headers):
    # Mock the conversational engine
    with patch.object(daemon.conversational_engine, 'handle_user_input', return_value="Hello Creator") as mock_handle:
        response = client.post("/api/chat", json={"message": "hello"}, headers=auth_headers)
        assert response.status_code == 200
        assert response.json()["response"] == "Hello Creator"
        mock_handle.assert_called_with("hello")

def test_action_endpoint(auth_headers):
    # Mock executor
    with patch.object(executor, 'execute_shell_command', return_value={"stdout": "foo", "stderr": "", "returncode": 0}) as mock_exec:
        response = client.post("/api/action", json={"command": "echo foo"}, headers=auth_headers)
        assert response.status_code == 200
        assert response.json()["stdout"] == "foo"
        mock_exec.assert_called_with("echo foo")

def test_download_endpoint(auth_headers):
    response = client.get(f"/api/download?token={SECRET_TOKEN}")
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/zip"

def test_upgrade_endpoint(auth_headers):
    with patch.object(daemon, 'run_self_improvement') as mock_run:
        response = client.post("/api/upgrade", headers=auth_headers)
        assert response.status_code == 200
        assert response.json()["status"] == "Upgrade cycle initiated."
        # Background tasks are hard to test synchronously without processing them, 
        # but the endpoint logic is verified.
